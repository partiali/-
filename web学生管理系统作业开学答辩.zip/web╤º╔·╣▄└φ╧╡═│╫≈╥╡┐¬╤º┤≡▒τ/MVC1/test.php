<?php
require_once './smarty/libs/Smarty.class.php';
require_once './views/DB.php';
require_once '../public/tools.php';
// require_once './testController.php';

$smarty = new smarty();
$smarty->template_dir = './views';//HTML模板地址

$pdo = DB::getInstance()->connect();

//1.接收参数
$controller = empty($_GET['controller']) ?'test' : $_GET['controller'];//test user
$method = empty($_GET['method']) ? 'index' : $_GET['method'];//myclass list edit

// 2.怎么把接收字符串变成可执行的类
// var_dump($controller);

eval("require_once './app/controller/{$controller}Controller.php';");
eval('$obj = new ' . $controller . 'Controller();');
eval('$obj->' . $method .'();');

//第一步：浏览者 -> 向控制器发送指令
// $test = new testController();
// $test->hello();


// $test->myclass();



