<?php
/* Smarty version 3.1.34-dev-7, created on 2022-11-15 07:59:11
  from 'D:\xampp\htdocs\MVC\views\nav.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_637338bfaf7ae6_52716932',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '32abc463351ad796a177bf25bba47a58ff6a4a08' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC\\views\\nav.html',
      1 => 1668495550,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_637338bfaf7ae6_52716932 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="layui-header">
  <div class="layui-logo layui-hide-xs layui-bg-black">layui 后台布局</div>
  <!-- 头部区域（可配合layui 已有的水平导航） -->
  <ul class="layui-nav layui-layout-left">
    <!-- 移动端显示 -->
    <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-header-event="menuLeft">
      <i class="layui-icon layui-icon-spread-left"></i>
    </li>
    
    <li class="layui-nav-item layui-hide-xs"><a href="">控制台</a></li>
    <li class="layui-nav-item layui-hide-xs"><a href="">商品管理</a></li>
    <li class="layui-nav-item layui-hide-xs"><a href="">用户</a></li>
   
    <li class="layui-nav-item">
      <a href="javascript:;">其他系统</a>
      <dl class="layui-nav-child">
        <dd><a href="">menu 11</a></dd>
        <dd><a href="">menu 22</a></dd>
        <dd><a href="">menu 33</a></dd>
      </dl>
    </li>
  </ul>
  <ul class="layui-nav layui-layout-right">
    <li class="layui-nav-item layui-hide layui-show-md-inline-block">
      <a href="javascript:;">
        <img src="//tva1.sinaimg.cn/crop.0.0.118.118.180/5db11ff4gw1e77d3nqrv8j203b03cweg.jpg" class="layui-nav-img">
       贤心
      </a>
      <dl class="layui-nav-child">
        <dd><a href="">Your Profile</a></dd>
        <dd><a href="">Settings</a></dd>
        <dd><a href="../server/server_logout.php">Sign out</a></dd>
      </dl>
    </li>
    <li class="layui-nav-item" lay-header-event="menuRight" lay-unselect>
      <a href="javascript:;">
        <i class="layui-icon layui-icon-more-vertical"></i>
      </a>
    </li>
  </ul>
</div>

<div class="layui-side layui-bg-black">
  <div class="layui-side-scroll">
    <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
    <ul class="layui-nav layui-nav-tree" lay-filter="test">
      <li class="layui-nav-item layui-nav-itemed">
        <a class="" href="javascript:;">用户管理</a>
        <dl class="layui-nav-child">
          <dd><a href="./test.php?controller=user&method=index">用户列表</a></dd>
          <dd><a href="javascript:;">添加用户</a></dd>
          <dd><a href="javascript:;">修改用户</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item">
        <a href="javascript:;">新闻管理</a>
        <dl class="layui-nav-child">
          <dd><a href="./test.php?controller=news&method=index">新闻列表</a></dd>
          <dd><a href="./test.php?controller=news&method=showedit">添加新闻</a></dd>
        </dl>
      </li>
      
    </ul>
  </div>
</div><?php }
}
