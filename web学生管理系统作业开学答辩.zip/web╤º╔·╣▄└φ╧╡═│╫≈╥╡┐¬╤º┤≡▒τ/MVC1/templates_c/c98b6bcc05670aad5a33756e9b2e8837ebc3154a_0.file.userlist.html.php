<?php
/* Smarty version 3.1.34-dev-7, created on 2022-11-14 10:05:04
  from 'D:\xampp\htdocs\MVC\views\userlist.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_637204c060fd29_88681842',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c98b6bcc05670aad5a33756e9b2e8837ebc3154a' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC\\views\\userlist.html',
      1 => 1668416421,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./nav.html' => 1,
  ),
),false)) {
function content_637204c060fd29_88681842 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>userlist</title>
  <link rel="stylesheet" href="../../layui/css/layui.css">
  <style>
    table img {
      width: 60px;
    }
  </style>
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <?php $_smarty_tpl->_subTemplateRender("file:./nav.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
      <a href="./useradd.php" class="layui-btn">
            <i class="layui-icon layui-icon-add-circle"></i>
            添加用户
      </a>
      <input type="text" name="search" placeholder="请输入搜索关键词">
      <button class="layui-btn layui-btn-sm" onclick="search()" >搜索</button>

         <table class="layui-table">
            <colgroup>
                <col width="150">
                <col width="200">
                <col>
              </colgroup>
            <thead>
                <tr>
                    <td>编号</td>
                    <td>头像</td>
                    <td>姓名</td>
                    <td>年龄</td>
                    <td>分类</td>
                    <td>创建时间</td>
                    <td>操作</td>
                </tr>
            </thead>
            <tbody >

              <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['user']->value) {
?>
              <tr>
                  <td><?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
</td>
                  <td><img src='../../server/uploads/<?php echo $_smarty_tpl->tpl_vars['user']->value['icon'];?>
' alt=''></td>
                  <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['username'];?>
</td>
                  <td> <?php echo $_smarty_tpl->tpl_vars['user']->value['age'];?>
</td>
                  <td><?php echo $_smarty_tpl->tpl_vars['user']->value['type_name'];?>
</td>
                  <td><?php echo $_smarty_tpl->tpl_vars['user']->value['show_time'];?>
</td>
                  <td>
                      <a class='layui-btn layui-btn-sm' href='./useredit.php?id=<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
' >编辑</a>
                      <button onclick='del(<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
)' class='layui-btn layui-btn-sm layui-btn-danger'>删除</button>
                  </td>
              </tr>
              <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

            </tbody>
         </table>
         <div id="pages"></div>
    </div>
  </div>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    @layui.com - 底部固定区域
  </div>
</div>
<?php echo '<script'; ?>
 src="../../layui/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="../../layui/layui.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    function search(){
      //1、获取数据
      var search = document.querySelector('input[name=search]').value;
      console.log(search);
      //2、过滤
      var strusers = localStorage.getItem("users");
      var users = JSON.parse(strusers);
      users = users.filter(user => user.username.indexOf(search) >= 0);
      //3、显示数据
      // loadData(users);
    } 

    function del(id) {
      layer.confirm('确认删除' + id + '?', {
        btn: ['确认', '取消',] //可以无限个按钮
        }, function(index, layero){
          //调用服务端的删除接口
          location.href = `../server/server_userdel.php?id= 1001`
           layer.close(index);
        }, function(index){
        //按钮【按钮二】的回调
        });
    }

    
    
              
  
  
  //JS 
  layui.use(['element', 'layer', 'util'], function(){
    var element = layui.element
    ,layer = layui.layer
    ,util = layui.util
    ,$ = layui.$
    ,laypage = layui.laypage;
  
    //执行一个laypage实例
    laypage.render({
      elem: 'pages' //注意，这里的 test1 是 ID，不用加 # 号
      ,count: <?php echo $_smarty_tpl->tpl_vars['count']->value;?>
 //数据总数，从服务端得到
      ,limit: 3
      ,curr: <?php echo $_smarty_tpl->tpl_vars['cur_page']->value;?>

      ,jump: function(obj, first){
        //obj包含了当前分页的所有参数，比如：
        
        console.log(obj.curr); //得到当前页，以便向服务端请求对应页的数据。
        console.log(obj.limit); //得到每页显示的条数
        
        //首次不执行
        if(!first){
          //do something
          location.href = './userlist.php?controller=user&method=index&cur_page=' + obj.curr;
        }
      }
    });
    

    
  });

      
<?php echo '</script'; ?>
> 

</body> 
</html><?php }
}
