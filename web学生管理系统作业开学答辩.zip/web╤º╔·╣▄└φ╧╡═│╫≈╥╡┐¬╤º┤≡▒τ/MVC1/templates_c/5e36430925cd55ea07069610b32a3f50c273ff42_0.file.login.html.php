<?php
/* Smarty version 3.1.34-dev-7, created on 2022-12-22 08:46:36
  from 'D:\xampp\htdocs\MVC1\views\login.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_63a40b5c336c69_04502923',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5e36430925cd55ea07069610b32a3f50c273ff42' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC1\\views\\login.html',
      1 => 1671694653,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63a40b5c336c69_04502923 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css" />
    <style>
        * {
            margin:0;
            padding:0;
        }
        body{
            display:flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: url(/MVC1/img/RC.jpg) no-repeat;
            background-size: cover;
        }
        .box {
            border-radius: 20px;
            display:flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 350px;
            height: 380px;
            border-top: 1px solid rgba(255, 255, 255, 0.5);
            border-left: 1px solid rgba(255, 255, 255, 0.5);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            background: rgba(50,50,50,0.2);
        }
        .box >h2 {
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 20px;
        }
        .box .input-box {
            display:flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        .box .input-box > label {
            margin-bottom:5px;
            color:rgba(255, 255, 255, 0.9);
            font-size: 13px;
        }
        .box .input-box > input {
            box-sizing: border-box;
            color:rgba(255, 255, 255, 0.9);
            font-size: 14px;
            height: 35px;
            width: 250px;
            background: rgba(255, 255, 255, 0.3);
            border:1px solid rgba(255, 255, 255, 0.5);
            border-radius: 5px;
            transition: 0.2s;
            outline:none;
            padding:0 10px;
            letter-spacing: 1px;
        }
        .box .input-box > input:focus {
            border:1px solid rgba(255, 255, 255, 0.8);

        }
        .box .btn-box {
            width: 250px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
        }
        
        .box .btn-box > a {
            font-size: 13px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.9);
            transition: 0.2s;
            width: 250px;
            text-align: end;
        }
        .box .btn-box > a:hover {
            color:rgba(255,255,255,1);
        }
        .box .btn-box > div {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: flex-start;
            margin-top: 20px;
        }
        button {
            width: 120px;
            height: 35px;
            border:1px solid rgba(197,81,58,0.8);
            background: rgba(197,81,58,0.5);
            color: rgba(255, 255, 255, 0.9);
            border-radius: 5px;
            transition: 0.2s;
        }
        /* .box .btn-box > div > button {
            width: 120px;
            height: 35px;
            border:1px solid rgba(197,81,58,0.8);
            background: rgba(197,81,58,0.5);
            color: rgba(255, 255, 255, 0.9);
            border-radius: 5px;
            transition: 0.2s;

        } */
        /* .box .btn-box > div >button:nth-of-type(2) {
            margin-left: 10px;
        } */
        button:hover {
            border: 1px solid rgba(248,108,76,0.8);
            background: rgba(248,108,76,0.5);   
        }
        </style>
</head>

<body>
    <h1>后台管理系统</h1>
    <form action="../server/server_login.php" method="post">
    <div class="box">
        <h2>Login</h2>
        <div class="input-box">
            <label for="">账号</label>
            <input type="text"  name="username"  placeholder="请输入用户名">
        </div>
        <div class="input-box">
            <label for="">密码</label>
            <input type="password" name="password"  placeholder="请输入密码" >
        </div>
        <div claass="btn-box">
            <a href="#">忘记密码？</a>
            <div>
                <button>登录</button>
                <button>注册</button>
            </div>
        </div>
    </div>
</form>
</body>
</html><?php }
}
