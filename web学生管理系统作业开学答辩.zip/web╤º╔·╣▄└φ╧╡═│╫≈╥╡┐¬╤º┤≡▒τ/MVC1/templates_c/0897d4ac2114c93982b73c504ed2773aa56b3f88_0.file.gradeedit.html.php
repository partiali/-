<?php
/* Smarty version 3.1.34-dev-7, created on 2022-12-25 15:41:19
  from 'D:\xampp\htdocs\MVC1\views\gradeedit.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_63a8610f1aad74_26806284',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0897d4ac2114c93982b73c504ed2773aa56b3f88' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC1\\views\\gradeedit.html',
      1 => 1671979259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./nav.html' => 1,
  ),
),false)) {
function content_63a8610f1aad74_26806284 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>layout 管理系统大布局 - Layui</title>
  <link rel="stylesheet" href="../layui/css/layui.css">
  <style>
    table img {
    width:60px;
  }
    #show_img {
    width: 80px;
  }
</style>
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <?php $_smarty_tpl->_subTemplateRender("file:./nav.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
      <form class="layui-form" action="./" onsubmit="return false">
        <h2>修改成绩</h2>

        <div class="layui-form-item">
          <label class="layui-form-label">学号</label>
          <div class="layui-input-block">
            <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['grade']->value['id'];?>
" name="" required  lay-verify="required" placeholder="请输入学号" autocomplete="off" class="layui-input">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">姓名</label>
          <div class="layui-input-block">
            <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['grade']->value['username'];?>
" name="username" required  lay-verify="required" placeholder="请输入姓名" autocomplete="off" class="layui-input">
          </div>
        </div>

        <div class="layui-form-item">
          <label class="layui-form-label">头像</label>
          <div class="layui-input-block">
            <input type="hidden" name="img" >
            <button type="button" class="layui-btn" id="test1">
              <i class="layui-icon">&#xe67c;上传文件</i>
            </button>
           <img id="show_img"  alt="">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">课程</label>
          <div class="layui-input-block">
            <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['grade']->value['course'];?>
" name="course" required  lay-verify="required" placeholder="请输入课程" autocomplete="off" class="layui-input">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">成绩</label>
          <div class="layui-input-block">
            <input type="text" value="<?php echo $_smarty_tpl->tpl_vars['grade']->value['mark'];?>
" name="mark" required  lay-verify="required" placeholder="请输入成绩" autocomplete="off" class="layui-input">
          </div>
        </div>
      
        <div class="layui-form-item">
          <label class="layui-form-label">学期</label>
          <div class="layui-input-block">
              <select name="term" lay-verify="required" lay-search>
                <option value=""></option>
                <!-- <option value="第一学期">第一学期</option>
                <option value="第二学期">第二学期</option>
                <option value="第三学期">第三学期</option> -->
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['types']->value, 'type', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['type']->value) {
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['type']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['type']->value['name'];?>
</option>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
             </select>
          </div>
        </div>
      

        
        <!-- <div class="layui-form-item">
          <label class="layui-form-label">内容</label>
          <div class="layui-input-block">
            <div id="editor">
                <?php echo $_smarty_tpl->tpl_vars['news']->value['content'];?>

            </div>
          </div>
        </div> -->

        <div class="layui-form-item">
          <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    @layui.com - 底部固定区域
  </div>
</div>


<?php echo '<script'; ?>
 src="../layui/layui.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="../layui/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="https://cdn.jsdelivr.net/npm/wangeditor@latest/dist/wangEditor.min.js"><?php echo '</script'; ?>
>
<!-- <?php echo '<script'; ?>
 type="text/javascript">
    const E = window.wangEditor
    const editor = new E("#editor")
    editor.config.uploadImgServer = './test.php?controller=upload&method=upload_wang'
    editor.config.uploadFileName = 'pic'
    editor.create();
<?php echo '</script'; ?>
> -->
<?php echo '<script'; ?>
>
  layui.use('form', function(){
    var form = layui.form;
    form.on('submit(formDemo)', function(data){
      // data.field.content = editor.txt.html();
      layer.msg(JSON.stringify(data.field));
      console.log(data.field);
      //2.ajax
      $.ajax({
        url:'./test.php?controller=grade&method=add',
        method:'post',
        data:data.field,
        success:function (res) {
            // history.go(-1);//返回上一页
            // location.reload(-1);//刷新
            res = JSON.parse(res);
            console.log(res);
            layer.msg(res.message);
        },
        error:function (err) {
            console.log(err);
        }
      })
      return false;
    });
    var upload = layui.upload;
   
  //执行实例
   upload.render({
    elem: '#test1' //绑定元素
    ,url: '../test.php?controller=upload&method=upload' //上传接口
    ,field:'pic'
    ,done: function(res){
      //上传完毕回调
      console.log(res);
      console.log(res['data']['src']);
      var icon = document.querySelector('input[name=img]');
      icon.value = res['data']['src'];

      var show_img = document.querySelector("#show_img");
      show_img.setAttribute('src','../uploads/'+ res['data']['src']);

    }
    ,error: function(err){
      //请求异常回调
      console.log(err);
    }
  });
  });
<?php echo '</script'; ?>
>
</body>
</html>
      
      <?php }
}
