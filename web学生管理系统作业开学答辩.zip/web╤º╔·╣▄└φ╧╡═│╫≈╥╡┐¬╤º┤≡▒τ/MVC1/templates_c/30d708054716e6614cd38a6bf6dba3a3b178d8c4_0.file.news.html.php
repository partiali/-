<?php
/* Smarty version 3.1.34-dev-7, created on 2022-11-08 03:04:08
  from 'D:\xampp\htdocs\MVC\views\news.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_6369b9189a62c6_56660902',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '30d708054716e6614cd38a6bf6dba3a3b178d8c4' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC\\views\\news.html',
      1 => 1667873046,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6369b9189a62c6_56660902 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border=""1px solid black>
        <tr>
            <th>姓名</th>
            <th>分类</th>
        </tr>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user', false, 'k');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['user']->value) {
?>
        <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value['name'];?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value['type'];?>
</td>
        </tr>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </table>
</body>
</html><?php }
}
