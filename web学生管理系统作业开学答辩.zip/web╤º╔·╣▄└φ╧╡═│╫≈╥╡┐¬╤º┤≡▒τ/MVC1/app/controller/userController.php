<?php
require_once './app/model/userModel.php';
require_once './app/view/userView.php';

class userController {
    public function index()
    {
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $model = new userModel();
        $users = $model -> getList($cur_page);
        $count = $model -> getCount();
        // var_dump($users);
        $view = new userview();
        $view -> show($users,$cur_page,$count );
    }
}

