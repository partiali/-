<?php
require_once './app/model/newsModel.php';
require_once './app/model/newsTypeModel.php';
require_once './app/view/newsView.php';

class newsController
{
    public function index()
    {
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $model = new newsModel();
        $list = $model->getlist($cur_page);
        $count = $model -> getCount();
        // var_dump($list);
        $view = new newsView();
        $view -> show($list,$cur_page,$count);
    }
    public function showadd()
    {
        $model = new newsTypeModel();
        $types = $model->getList();

        $view = new newsView();
        $view -> add($types);
    }
    public function add()
    {
        // $data = $_POST;
        $model = new newsModel();
        $res = $model->add($_POST);
        // echo $res;
        json(200,'添加成功');
    }
    public function showedit()
    {
        $model = new newsTypeModel();
        $types = $model->getList();
        $id = $_GET['id'];
        $news_model = new newsModel();
        $news = $news_model-> getNews($id);


        $view = new newsView();
        $view -> edit($types,$news);
    }
}