

<?php
require_once './app/model/gradeModel.php';
require_once './app/model/gradeTypeModel.php';
require_once './app/view/gradeView.php';

class gradeController
{
    public function index()
    {
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $model = new gradeModel();
        $grades = $model->getlist($cur_page);
        $count = $model -> getCount();
        // var_dump($grades);
        $view = new gradeView();
        $view -> showList($grades,$cur_page,$count);
    }
    public function showadd()
    {
        $model = new gradeTypeModel();
        $types = $model->getList();
        // var_dump($types);
        $view = new gradeView();
        $view -> add($types);
    }
    public function add()
    {
        // $data = $_POST;
        $model = new gradeModel();
        $res = $model->add($_POST);
        // echo $res;
        json(200,'添加成功');
    }
    public function showedit()
    {
        $model = new gradeTypeModel();
        $types = $model->getList();
        $id = $_GET['id'];
        $grade_model = new gradeModel();
        $grade = $grade_model-> getGrade($id);


        $view = new gradeView();
        $view -> edit($types,$grade);
    }
}