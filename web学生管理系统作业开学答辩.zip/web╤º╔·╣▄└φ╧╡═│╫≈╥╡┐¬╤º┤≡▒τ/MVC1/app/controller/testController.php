<?php
require_once './app/controller/testModel.php';
require_once './app/controller/testView.php';

class testController {
    public function hello(){
        

        // 第二步：控制器 -> 按照指令选取合适的模型
        $model = new testModel();
        // 第三步：模型 -> 按照控制器指令选取合适的模型
        $data = $model -> getdata();
        // 第四步：控制器 -> 按照指令选取相应视图
        $view = new testView();
        // 第五步：视图 -> 按照指令选取合适的模型
        $view->show($data);
    }

    public function  stu()
    {
        // 第二步：控制器 -> 按照指令选取合适的模型
        $model = new testModel();

        // 第三步：模型 -> 按照控制器指令选取合适的模型
        $listdata = $model -> getlistdata();

        // 第四步：控制器 -> 按照指令选取相应视图
        $listview = new testView();

        // 第五步：视图 -> 把第三步取到的数据按用户想要的样子显示出来
        $listview->listshow($listdata);

    }

    public function myclass()
    {
        $model = new testModel();
        $data = $model -> getlistdata();
        $view = new testview();
        $view -> showSmarty($data);
    }
}

