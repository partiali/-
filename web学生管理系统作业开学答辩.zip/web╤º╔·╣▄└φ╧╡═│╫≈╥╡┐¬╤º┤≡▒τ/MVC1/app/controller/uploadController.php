<?php
class uploadController
{
    public function upload()
    {
        move_uploaded_file($_FILES['pic']['tmp_name'],'./uploads/' . $_FILES['pic']['name']);
        $res = [
        'code' => 0,
        'msg' => 'success',
        'data' => [
            'src' => $_FILES['pic']['name']
        ]
        ];
        echo json_encode($res,JSON_UNESCAPED_UNICODE);
    }
    // public function upload_wang()
    // {
    //     move_uploaded_file($_FILES['pic']['tmp_name'],'./uploads/' . $_FILES['pic']['name']);
    //     $res = [
    //             'errno' => 0,
    //             'data' => [
    //             [
    //                 'url' => './uploads/' . $_FILES['pic']['name'],
    //                 'alt' => '图片文字说明',
    //                 'href' => '跳转链接'
    //             ]
    //         ]
    //         ];
    //         echo json_encode($res,JSON_UNESCAPED_UNICODE);
    // }
}