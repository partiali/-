<?php
require_once './app/model/loginModel.php';
require_once './app/view/loginView.php';

class loginController {
    public function index()
    {
        $model = new loginModel();
        $data = $model -> getdata();
        $view = new loginview();
        $view -> show($data);
    }
}

