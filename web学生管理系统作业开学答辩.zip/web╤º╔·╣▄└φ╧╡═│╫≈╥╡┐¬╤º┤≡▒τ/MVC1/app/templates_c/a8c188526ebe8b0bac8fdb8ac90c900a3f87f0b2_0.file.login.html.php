<?php
/* Smarty version 3.1.34-dev-7, created on 2022-11-08 08:21:44
  from 'D:\xampp\htdocs\MVC\app\view\login.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_636a038869b3a2_83441654',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a8c188526ebe8b0bac8fdb8ac90c900a3f87f0b2' => 
    array (
      0 => 'D:\\xampp\\htdocs\\MVC\\app\\view\\login.html',
      1 => 1667890381,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_636a038869b3a2_83441654 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../layui/css/layui.css">
    <style>
       #container {
        position: absolute;
        top:0;
        bottom:0;
        right:0;
        left:0;
        margin:auto;
        padding: 20px 40px;
        width: 400px;
        
        height: 300px;background-color: white;
       }
       h1 {
        font-size: 20px;
        text-align: center;
        margin-bottom: 20px;
        color:black;
       }
    </style>
</head>
<body class="layui-bg-green">
    <div id="container" class="layui-container">
        <h1>后台管理系统</h1>
        <form class="layui-form" action="../server/server_login.php" method="post">
            <div class="layui-form-item">
                <input class="layui-input" name="username" type="text" placeholder="请输入用户名" >
            </div>
            <div class="layui-form-item">
                <input class="layui-input" name="password" type="password" placeholder="请输入密码" >
            </div>
           
            <div class="layui-form-item layui-row">
                <div class="layui-col-xs5"  >
                    <button class="layui-btn layui-btn-fluid layui-btn-primary layui-col-xs3">注册</button>
                </div>
                <div class="layui-col-xs5 layui-col-xs-offset1">
                    <button  class="layui-btn layui-btn-fluid layui-col-xs3 layui-col-xs-offset2" >登录</button>
                </div>
            </div>


        </form>
    </div>
    
</body>
</html><?php }
}
