<?php

class newsModel 
{
    public function getCount()
    {
        global $pdo;
        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT COUNT(*) as num FROM `news` ");//返回一个PDOStatement对象
        $res = $stmt->fetch();
        // var_dump($res);
        return $res['num'];  
    }

    public function getList($cur_page)
    {
        global $pdo;
        
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $page_size = 3;
        $index = ($cur_page - 1)*3;

        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT news.*,news_type.`name` FROM news LEFT JOIN news_type ON news.type_id = news_type.id LIMIT $index,3");//返回一个PDOStatement对象
        return  $stmt->fetchAll();//获取所有
    }

    public function getNews($id)
    {
        global $pdo;
        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT news.*,news_type.`name` FROM news LEFT JOIN news_type ON news.type_id = news_type.id WHERE news.id = 1");//返回一个PDOStatement对象
        return  $stmt->fetch();
    }
    
    public function add($data)
    {
        global $pdo;
        //1 查询
        //查询总条数
        return  $pdo->exec("INSERT INTO `news` (title,type_id,img,content) VALUES ('$data[title]',$data[type_id],'$data[img]','$data[content]');");//返回一个PDOStatement对象
        // return  $stmt->fetchAll();
    }
}