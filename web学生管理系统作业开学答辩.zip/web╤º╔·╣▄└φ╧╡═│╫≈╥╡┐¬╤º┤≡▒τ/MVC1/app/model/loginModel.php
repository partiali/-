<?php
class loginModel {
   
    public function getData(){
        return [
            ['username'=>'张三','pwd' =>'123'],
            ['username'=>'李四','pwd' =>'456']
        ];   
    }
}