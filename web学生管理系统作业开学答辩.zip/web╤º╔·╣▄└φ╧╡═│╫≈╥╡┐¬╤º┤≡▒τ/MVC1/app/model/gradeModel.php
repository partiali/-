<?php

class gradeModel 
{
    public function getCount()
    {
        global $pdo;
        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT COUNT(*) as num FROM `grade` ");//返回一个PDOStatement对象
        $res = $stmt->fetch();
        // var_dump($res);
        return $res['num'];  
    }

    public function getList($cur_page)
    {
        global $pdo;
        
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $page_size = 3;
        $index = ($cur_page - 1)*3;

        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT grade.*,grade_type.`name` FROM grade LEFT JOIN grade_type ON grade.term = grade_type.id LIMIT $index,3");//返回一个PDOStatement对象
        return  $stmt->fetchAll();//获取所有
    }

    public function getGrade($id)
    {
        global $pdo;
        //1 查询
        
        $stmt = $pdo->query("SELECT grade.*,grade_type.`name` FROM grade LEFT JOIN grade_type ON grade.term = grade_type.id WHERE grade.id = 1001");//返回一个PDOStatement对象
        return  $stmt->fetch();
    }
    
    public function add($data)
    {
        global $pdo;
        //1 查询
        //查询总条数
        return  $pdo->exec("INSERT INTO `grade` (id,username,img,course,grade,term) VALUES ($data[id],'$data[username]','$data[img]','$data[course]',$data[grade],$data[term]);");//返回一个PDOStatement对象
    }
}


