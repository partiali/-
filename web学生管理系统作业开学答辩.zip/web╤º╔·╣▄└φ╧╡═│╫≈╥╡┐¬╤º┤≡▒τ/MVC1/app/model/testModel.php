<?php
class testModel {
    public function getData(){
        return 'web';
    }
    public function getlistData(){
        return [
            ['name'=>'张三','type' =>'学生'],
            ['name'=>'李四','type' =>'老师']
        ];   
    }
}