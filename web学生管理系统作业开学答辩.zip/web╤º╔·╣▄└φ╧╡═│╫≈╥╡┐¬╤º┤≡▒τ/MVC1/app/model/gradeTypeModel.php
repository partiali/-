<?php

class gradeTypeModel {
    public function getList()
    {
        global $pdo;
        
        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT * FROM grade_type");//返回一个PDOStatement对象
        return  $stmt->fetchAll();
}
}