<?php
class userModel {
    public function getCount()
    {
        global $pdo;
        //1 查询
        //查询总条数
        $stmt = $pdo->query("SELECT COUNT(*) as num FROM `user` ");//返回一个PDOStatement对象
        $res = $stmt->fetch();
        // var_dump($res);
        return $res['num'];  
    }

    public function getList($cur_page)
    {
        global $pdo;
        
        $cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
        $page_size = 3;
        $index = ($cur_page - 1)*3;
        //1)使用query
        $stmt = $pdo->query("SELECT * FROM `user` LIMIT $index,3"); //返回一个PDOStatement对象

        $users = $stmt->fetchAll(); //获取所有
        // print_r($rows);
        foreach ($users as $key => &$user) {
        $user['show_time'] = date('Y-m-d',$user['create_time']);
            $type_name = '';
            switch ($user['type']) {
                case '1':
                    $type_name = '老师';
                    break;
                case '2':
                    $type_name = '学生';
                    break;
                case '3':
                    $type_name = '工人';
                    break;
                default:
                    $type_name= '未知';
                    break;
            }
            $user['type_name'] = $type_name;
        }  
        return $users;
            }
}