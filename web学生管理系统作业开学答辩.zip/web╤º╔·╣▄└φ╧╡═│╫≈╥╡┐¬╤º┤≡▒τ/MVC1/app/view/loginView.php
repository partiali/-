<?php
class loginView{
    public function show($data)
    {
        global $smarty;
        // $smarty -> assign('users',$data);
        $smarty -> display('login.html');
      
    }
}