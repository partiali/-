

<?php
class gradeView{
    public function showList($grades,$cur_page,$count)
    {
        global $smarty;
        // 把数据从PHP传到html
        $smarty -> assign('grades',$grades);
        $smarty -> assign('cur_page',$cur_page);
        $smarty -> assign('count',$count);
        $smarty -> display('gradelist.html');
    }
    public function add($types)
    {
        global $smarty;
        $smarty -> assign('types',$types);
        $smarty -> display('gradeadd.html');
    }
    public function edit($types,$grade)
    {
        global $smarty;
        $smarty -> assign('types',$types);
        $smarty -> assign('grade',$grade);
        $smarty -> display('gradeedit.html');
    }
}