
<?php
class newsView{
    public function show($list,$cur_page,$count)
    {
        global $smarty;
        // 把数据从PHP传到html
        $smarty -> assign('list',$list);
        $smarty -> assign('cur_page',$cur_page);
        $smarty -> assign('count',$count);
        $smarty -> display('newslist.html');
    }
    public function add($types)
    {
        global $smarty;
        $smarty -> assign('types',$types);
        $smarty -> display('newsadd.html');
    }
    public function edit($types,$news)
    {
        global $smarty;
        $smarty -> assign('types',$types);
        $smarty -> assign('news',$news);
        $smarty -> display('newsedit.html');
    }
}