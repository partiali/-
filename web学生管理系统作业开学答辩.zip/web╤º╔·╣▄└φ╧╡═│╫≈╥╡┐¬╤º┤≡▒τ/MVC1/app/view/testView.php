<?php
class testView{
    public function show($data)
    {
      echo '<h1> 欢迎, ' .$data . '</h1>';
    }

    public function listshow($listdata)
    {
        foreach ($listdata as $key => $user) {
            echo  "<ul>
                <li>$user[name] : $user[type] </li>
            </ul>";
        }
    }

    public function showSmarty($data)
    {
        global $smarty;
        $smarty -> assign('users',$data);
        $smarty -> display('news.html');
    }

    
}