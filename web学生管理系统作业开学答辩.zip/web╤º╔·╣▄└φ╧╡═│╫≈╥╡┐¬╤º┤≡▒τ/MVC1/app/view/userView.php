<?php
class userView{
    public function show($users,$cur_page,$count)
    {
        global $smarty;
        // 把数据从PHP传到html
        $smarty -> assign('users',$users);
        $smarty -> assign('cur_page',$cur_page);
        $smarty -> assign('count',$count);
        $smarty -> display('userlist.html');
    }
}