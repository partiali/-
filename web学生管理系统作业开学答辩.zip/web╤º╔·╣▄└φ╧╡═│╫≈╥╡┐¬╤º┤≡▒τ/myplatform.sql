/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : localhost:3306
 Source Schema         : myplatform

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 08/02/2023 20:28:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` int(0) NULL DEFAULT NULL,
  `create_time` int(0) NULL DEFAULT NULL,
  `delete_time` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', '111', 2, NULL, NULL);
INSERT INTO `admin` VALUES (2, 'lisi', 'admin2', 1, 1636985071, NULL);
INSERT INTO `admin` VALUES (5, 'zhangsan', '111113', 2, NULL, NULL);
INSERT INTO `admin` VALUES (6, 'Tom', '123456', 1, 1636985071, NULL);
INSERT INTO `admin` VALUES (7, 'John', '654321', 2, 1636985071, 1669020859);
INSERT INTO `admin` VALUES (8, '卧龙', '000', 1, 1669728769, NULL);

-- ----------------------------
-- Table structure for grade
-- ----------------------------
DROP TABLE IF EXISTS `grade`;
CREATE TABLE `grade`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `course` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mark` int(0) NULL DEFAULT NULL,
  `term` tinyint(0) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1009 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of grade
-- ----------------------------
INSERT INTO `grade` VALUES (1001, '小明', '语文', 'user1.jpg', 78, 1, '2022-12-25 20:31:45');
INSERT INTO `grade` VALUES (1002, '张三', '计算机', 'user1.jpg', 89, 1, '2022-12-25 20:31:47');
INSERT INTO `grade` VALUES (1003, '李四', '英语', 'user1.jpg', 90, 1, '2022-12-25 20:31:48');
INSERT INTO `grade` VALUES (1004, '王五', '英语', 'user1.jpg', 80, 1, '2022-12-25 20:31:49');
INSERT INTO `grade` VALUES (1005, '赵六', '数学', 'user1.jpg', 90, 1, '2022-12-25 20:31:50');
INSERT INTO `grade` VALUES (1006, '周七', '语文', 'user1.jpg', 98, 1, '2022-12-25 20:31:55');
INSERT INTO `grade` VALUES (1007, '小红', '语文', 'user1.jpg', 78, 1, NULL);
INSERT INTO `grade` VALUES (1008, '小红', '语文', NULL, 78, 1, NULL);

-- ----------------------------
-- Table structure for grade_type
-- ----------------------------
DROP TABLE IF EXISTS `grade_type`;
CREATE TABLE `grade_type`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `state` tinyint(0) UNSIGNED NULL DEFAULT 1 COMMENT '状态：1-开通；2-关闭',
  `create_time` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1005 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of grade_type
-- ----------------------------
INSERT INTO `grade_type` VALUES (1, '第一学期', 1, 1605172258);
INSERT INTO `grade_type` VALUES (2, '第二学期', 1, 1605172258);
INSERT INTO `grade_type` VALUES (3, '第三学期', 1, 1605172258);
INSERT INTO `grade_type` VALUES (4, '其他', 1, 1605172258);

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `content` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type_id` int(0) NULL DEFAULT NULL COMMENT '分类id',
  `user_id` int(0) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES (1, '欢迎平台成立', NULL, NULL, NULL, 1, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (2, 'success', '<p>欢迎使用 <b>wangEditor</b> 富文本编辑器</p><p>kjkl&nbsp;</p><p><img src=\"./admin/uploads/1605575194校徽(1).png\" style=\"max-width:100%;\"><br></p>', 'user2.jpg', 2, NULL, '2020-11-17 09:06:22');
INSERT INTO `news` VALUES (3, '你好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-12 14:46:00');
INSERT INTO `news` VALUES (4, '你好111', '<p>hello</p>', 'user1.jpg', 2, NULL, '2020-11-13 14:46:00');
INSERT INTO `news` VALUES (5, '大家好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-14 14:46:00');
INSERT INTO `news` VALUES (6, '我很好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-15 14:46:00');
INSERT INTO `news` VALUES (7, 'very好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-16 14:46:00');
INSERT INTO `news` VALUES (8, '欢迎平台成立', NULL, NULL, 3, 1, '2020-11-17 14:46:00');
INSERT INTO `news` VALUES (9, '欢迎平台成立', NULL, NULL, 3, 1, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (10, 'success', '<p>欢迎使用 <b>wangEditor</b> 富文本编辑器</p><p>kjkl&nbsp;</p><p><img src=\"./admin/uploads/1605575194校徽(1).png\" style=\"max-width:100%;\"><br></p>', 'user2.jpg', 2, NULL, '2020-11-18 09:06:22');
INSERT INTO `news` VALUES (11, '你好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-19 14:46:00');
INSERT INTO `news` VALUES (12, '你好111', '<p>hello</p>', 'user1.jpg', 2, NULL, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (13, '大家好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (14, '我很好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (15, 'very好', '<p>hello</p>', 'user1.jpg', 1, NULL, '2020-11-11 14:46:00');
INSERT INTO `news` VALUES (16, '地方', '<p>欢迎使用 <b>wangEditor</b> 富文本编辑器</p><p>范德萨<img src=\"./admin/uploads/1606190404兵哥学编程.jpg\" style=\"max-width: 100%;\"></p>', 'user2.jpg', 4, NULL, '2020-11-24 00:00:00');
INSERT INTO `news` VALUES (17, '2', '<p>欢迎使用 <b>wangEditor</b> 富文本编辑器</p><p><img src=\"./admin/uploads/1606705241兵哥学编程.jpg\" style=\"max-width:100%;\"><br></p>', 'user2.jpg', 2, NULL, '2020-11-25 00:00:00');
INSERT INTO `news` VALUES (18, '2', '<p>欢迎使用 <b>wangEditor</b> 富文本编辑器</p><p><img src=\"./admin/uploads/1606706987token讲解.png\" style=\"max-width:100%;\"><br></p><p><img src=\"http://localhost:80/phpworkspace/HRSystem/base/demo/teach/admin/uploads/1606707426安信工.jpg\" style=\"max-width:100%;\"><br></p>', '', 2, NULL, '2020-11-17 00:00:00');
INSERT INTO `news` VALUES (19, 'kjh ', '<h1><b id=\"fcn6z\">欢迎使用 wangEditor 富文本编辑器</b></h1><p><img src=\"http://localhost:3000/stage2_PHP/platform/demo/teach/admin/uploads/1666681296tencent.png\" style=\"max-width:100%;\" contenteditable=\"false\"/></p>', '', 2, NULL, '2022-10-25 00:00:00');
INSERT INTO `news` VALUES (20, 'qwe', NULL, 'user2.jpg', 2, NULL, NULL);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` tinyint(0) NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` tinyint(0) NULL DEFAULT NULL,
  `birthday` date NULL DEFAULT NULL,
  `create_time` int(0) NULL DEFAULT NULL,
  `update_time` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1032 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1001, '小明', '111', 14, '男', '1.jpg', 2, '2022-10-15', 1604993572, 1671726136);
INSERT INTO `user` VALUES (1002, '张三', '123', 21, '女', '1.jpg', 1, '2022-01-01', 0, 79879);
INSERT INTO `user` VALUES (1003, '李四', '111', 23, '男', '2.jpg', 2, '2014-08-26', 0, 0);
INSERT INTO `user` VALUES (1004, '王五', NULL, 23, '男', '2.jpg', 2, NULL, NULL, NULL);
INSERT INTO `user` VALUES (1005, '赵六', NULL, 65, '女', '1.jpg', 2, NULL, NULL, NULL);
INSERT INTO `user` VALUES (1006, '周七', NULL, 20, '女', '1.jpg', 1, '2022-10-11', NULL, NULL);
INSERT INTO `user` VALUES (1007, '吴八', NULL, 23, '女', '1.jpg', 1, '2022-10-20', 1666349315, NULL);
INSERT INTO `user` VALUES (1008, '郑九', NULL, 45, '女', '1.jpg', 3, '2022-10-05', 1666360007, 1671653757);
INSERT INTO `user` VALUES (1009, '高三', NULL, 4, '女', '1.jpg', 2, '1999-05-26', 1670060661, 1671653434);
INSERT INTO `user` VALUES (1010, '梁拾', NULL, 23, '女', '2.jpg', 1, '2022-10-21', 1666611571, NULL);
INSERT INTO `user` VALUES (1011, '小猫', NULL, 2, '男', '1.jpg', 1, '2022-12-01', 1669861058, NULL);
INSERT INTO `user` VALUES (1012, '小丽', NULL, 13, '男', '1.jpg', 2, '2022-12-09', 1671820096, NULL);

-- ----------------------------
-- Table structure for user2
-- ----------------------------
DROP TABLE IF EXISTS `user2`;
CREATE TABLE `user2`  (
  `id` int(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `age` tinyint(0) NULL DEFAULT NULL,
  `type` tinyint(0) NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` date NOT NULL,
  `create_time` int(0) NULL DEFAULT NULL,
  `update_time` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user2
-- ----------------------------
INSERT INTO `user2` VALUES (0001, '小明', '111', 12, 1, 'user1.jpg', '2022-12-08', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
