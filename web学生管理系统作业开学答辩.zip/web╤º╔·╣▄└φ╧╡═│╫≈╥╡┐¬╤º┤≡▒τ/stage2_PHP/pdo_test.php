<?php
/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2017/11/28
 * Time: 8:51
 */

//参考：https://www.cnblogs.com/52fhy/p/5352304.html

//1、配置参数
$pd0 = array(
    'dsn' => 'mysql:host=localhost;dbname=myplatform;port=3306;charset=utf8',
    'username' => 'root',
    'password' => 123456,
);

//连接属性
$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, //默认是PDO::ERRMODE_SILENT, 0, (忽略错误模式)
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // 默认是PDO::FETCH_BOTH, 4
);

//2、连接数据库
try{
    $pdo = new PDO($pd0['dsn'],$pd0['username'],$pd0['password'],$options);
}catch(PDOException $e){
    die('数据库连接失败:' . $e->getMessage());
}

echo '<pre/>';

//1 查询

//1)使用query
$stmt = $pdo->query('select * from user'); //返回一个PDOStatement对象

//$row = $stmt->fetch(); //从结果集中获取下一行，用于while循环
$rows = $stmt->fetchAll(); //获取所有
//
$row_count = $stmt->rowCount(); //记录数

print_r($rows);

// echo '<br>';

//2 新增、更新、删除
//1)普通操作
// $count  =  $pdo->exec("INSERT into user(id,username,password,age,icon,type,birthday,create_time,update_time)
// VALUES(1009,'php','111',23,'user2.jpg',2,'2014-08-26',0,0)"); //返回受影响的行数
//echo $pdo->lastInsertId();
//
//  $count  =  $pdo->exec("update user set email='web@qq' where id = 10"); //返回受影响的行数
// $count  =  $pdo->exec("delete from  user where id = 9"); //返回受影响的行数
//echo $count;


