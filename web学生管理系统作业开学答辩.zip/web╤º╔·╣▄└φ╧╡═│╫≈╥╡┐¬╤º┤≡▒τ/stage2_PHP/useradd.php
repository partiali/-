
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>layout 管理系统大布局 - Layui</title>
  <link rel="stylesheet" href="../layui/css/layui.css">
  <style>
    table img {
    width:60px;
  }
    #show_img {
    width: 80px;
  }
</style>
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo layui-hide-xs layui-bg-black">学生管理系统</div>
    <!-- 头部区域（可配合layui 已有的水平导航） -->
    <ul class="layui-nav layui-layout-left">
      <!-- 移动端显示 -->
      <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-header-event="menuLeft">
        <i class="layui-icon layui-icon-spread-left"></i>
      </li>
      
      <li class="layui-nav-item layui-hide-xs"><a href="">控制台</a></li>
      <li class="layui-nav-item layui-hide-xs"><a href="">商品管理</a></li>
      <li class="layui-nav-item layui-hide-xs"><a href="">学生</a></li>
     
      <li class="layui-nav-item">
        <a href="javascript:;">其他系统</a>
        <dl class="layui-nav-child">
          <dd><a href="">menu 11</a></dd>
          <dd><a href="">menu 22</a></dd>
          <dd><a href="">menu 33</a></dd>
        </dl>
      </li>
    </ul>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item layui-hide layui-show-md-inline-block">
        <a href="javascript:;">
          <img src="//tva1.sinaimg.cn/crop.0.0.118.118.180/5db11ff4gw1e77d3nqrv8j203b03cweg.jpg" class="layui-nav-img">
         贤心
        </a>
        <dl class="layui-nav-child">
          <dd><a href="">Your Profile</a></dd>
          <dd><a href="">Settings</a></dd>
          <dd><a href="">退出</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item" lay-header-event="menuRight" lay-unselect>
        <a href="javascript:;">
          <i class="layui-icon layui-icon-more-vertical"></i>
        </a>
      </li>
    </ul>
  </div>
  
  <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree" lay-filter="test">
        <li class="layui-nav-item layui-nav-itemed">
          <a class="" href="javascript:;">学生管理</a>
          <dl class="layui-nav-child">

            <dd><a href="./userlist.php">学生列表</a></dd>
            <dd><a href="javascript:;">添加学生</a></dd>
            <dd><a href="javascript:;">修改学生</a></dd>
          
          </dl>
        </li>
        <li class="layui-nav-item">
          <a href="javascript:;">新闻管理</a>
          <dl class="layui-nav-child">
            <dd><a href="javascript:;">新闻列表</a></dd>
            <dd><a href="javascript:;">添加新闻</a></dd>
            
          </dl>
        </li>
        <!-- <li class="layui-nav-item"><a href="javascript:;">云市场</a></li>
        <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
  </div>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
      <form class="layui-form" action="" onsubmit="return false">
        <h2>添加学生</h2>
        <div class="layui-form-item">
          <label class="layui-form-label">姓名</label>
          <div class="layui-input-block">
            <input type="text" name="username" required  lay-verify="required" placeholder="请输入姓名" autocomplete="off" class="layui-input">
          </div>
        </div>
        <div class="layui-form-item">
          <label class="layui-form-label">年龄</label>
          <div class="layui-input-block">
            <input type="text" name="age" required  lay-verify="required" placeholder="请输入年龄" autocomplete="off" class="layui-input">
          </div>
        </div>

        <div class="layui-form-item">
          <label class="layui-form-label">性别</label>
          <div class="layui-input-block">
            <select name="sex" lay-verify="required" lay-search>
              <option value="男">男</option>
              <option value="女">女</option>
              
            </select>
          </div>
        </div>

        <div class="layui-form-item">
          <label class="layui-form-label">生日</label>
          <div class="layui-input-block">
            <input type="date" name="birthday" required  lay-verify="required" placeholder="请输入生日" autocomplete="off" class="layui-input">
          </div>
        </div>

        <div class="layui-form-item">
          <label class="layui-form-label">分类</label>
          <div class="layui-input-block">
            <select name="type" lay-verify="required" lay-search>
              <option value="1">老师</option>
              <option value="2">学生</option>
              <option value="3">工人</option>
            </select>
          </div>
        </div>

        <div class="layui-form-item">
          <label class="layui-form-label">头像</label>
          <div class="layui-input-block">
            <input type="hidden" name="icon" >
            <button type="button" class="layui-btn" id="test1">
              <i class="layui-icon">&#xe67c;上传文件</i>
            </button>
           <img id="show_img"  alt="">
          </div>
        </div>

        <div class="layui-form-item">
          <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    @layui.com - 底部固定区域
  </div>
</div>


<script src="../layui/layui.js"></script>
<script src="../layui/jquery.min.js"></script>
<script>
  layui.use('form', function(){
    var form = layui.form;
    form.on('submit(formDemo)', function(data){
      layer.msg(JSON.stringify(data.field));
      console.log(data.field);
      //2.ajax
      $.ajax({
        url:'../server/server_useradd.php',
        method:'post',
        data:data.field,
        success:function (res) {
            history.go(-1);//返回上一页
            // location.reload(-1);//刷新
            console.log(res);
        },
        error:function (err) {
            console.log(err);
        }
      })
      return false;
    });
    var upload = layui.upload;
   
  //执行实例
   upload.render({
    elem: '#test1' //绑定元素
    ,url: '../server/upload.php/' //上传接口
    ,field:'pic'
    ,done: function(res){
      //上传完毕回调
      console.log(res);
      console.log(res['data']['src']);
      var icon = document.querySelector('input[name=icon]');
      icon.value = res['data']['src'];

      var show_img = document.querySelector("#show_img");
      show_img.setAttribute('src','../server/uploads/'+ res['data']['src']);

    }
    ,error: function(err){
      //请求异常回调
      console.log(err);
    }
  });
  });
</script>
</body>
</html>
      