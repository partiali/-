<?php
require 'users.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
            <tr>
                <td>姓名</td>
                <td>年龄</td>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($users as $key => $value) {
                echo 
                "<tr>
                <td>$value[name]</td>
                <td>{$value['age']}</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
<!-- <?php 
include 'users.php';
echo $name1;
?> -->