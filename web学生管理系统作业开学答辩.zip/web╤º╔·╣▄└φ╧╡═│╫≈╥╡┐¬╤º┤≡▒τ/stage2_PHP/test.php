


<?php
echo 'hello world';


$a = 1;
$b;
const PI = 3.1415;
echo PI;

echo '<br>';
$str = 'web $a';
$str1 = "web $a";
echo $str;
echo '<br>';
echo $str1;

// $arr = ['web','java','python',999];


//平年和闰年的判断
$year = 2000;
$name;
if($year%4 == 0 && $year%100 !== 0 ){
     $name="闰年";
}else if($year%4 == 0 && $year% 400 == 0){
    $name = "闰年";
}else{
    $name = "平年";
}
echo '<br>';
echo $year.'是'.$name;

// $sum = 0;
// for($n = 0;$n<100;$n++){
//      $sum = $sum+$n;
// }
// echo '<br>';
// echo $sum;

$array = [
    '第一排' =>
        [
        'a' => '张三',
        'b' => '李四'
       ],
     '第二排' =>
        [
        'c' => '王五',
        'd' => '赵六'
        ]
     ];
     echo $array['第一排']['a']; 
    

$arr = ['web','java','python',999];
echo '<br>';
for ($i=0; $i < count($arr) ; $i++) { 
    # code...
    echo $arr[$i] . ',';
}

echo '<br>';
foreach ($arr as $key => $value) {
    # code...
    echo $value . ',';
}



 $arra = [
    [
        'id'=>1001,
        'icon' => '004.jpg',
        'name'>='安信工',
        'age'=>10,
        'type'=>'学生'
    ],
    [
        'id' =>1002,
        'icon' => '004.jpg',
        'name'>= '国庆',
        'age' => 73,
        'type'=>'学生'
    ],
    [
        'id' =>1003,
        'icon' => '004.jpg',
        'name'>='web',
        'age'=>18,
        'type'=>'学生'
        ]
    ];
    echo '<br>';
    var_dump($arra);
    
    echo '<br>';
 

    function add(&$a,$b = 0){
        $a++;
        echo $a+$b;
    }

    $s1 = 9;
    add($s1);

    echo '<br>';
    echo $s1;

    // add(1,2);
    echo '<br>';
    $sum = 0;
    for($n = 0;$n<100;$n++){
        $sum = $sum+$n;
    }
    echo '<br>';
    echo $sum;

    echo '<br>';
    
    function add1($num){
        $sum = 0;
     for ($i=1; $i <= $num ; $i++) { 
        # code...
        $sum +=$i;
     }
     echo $sum;
    }
    add1(100);

    echo '<br>';
    $a = 10;
    $b = 5;
    $c = 8;
    $max1 = $a>$b ? $a:$b;
    $max = $c>$max1 ? $c:$max1;
    $min2 = $a<$b ? $a:$b;
    $min = $c<$min2 ? $c:$min2;
    
    if( $max != $a &&  $min != $a ){
        $mid = $a;
    }else  if($max != $b && $min != $b){
        $mid = $b;
    }else  if( $max!= $c &&  $min != $c){
        $mid = $c;
    }
    echo $mid;
    echo '<br>';
    echo $max. ">" . $mid . ">" . $min;

    echo '<br>';
    // $a = 10;
    // $b = 3;
    // $c = 6;

    function mysort($v1,$v2,$v3) {
        // 1、第一轮比较，找出做大的
        // $max = $v1>$v2 ? $v1:$v2;
        // $max = $max>$v3 ? $max:$v3;
        //2第二轮比较
        $arr = [$v1,$v2,$v3];
        var_dump($arr);
        echo '<br>';
        sort($arr);
        show($arr);
    }
    function show($arr){
        foreach ($arr as $key => $value) {
            # code...
            echo "$value < ";
        }
    }
    $a = 10;
    $b = 3;
    $c = 6;
    mysort($a,$b,$c);

    echo '<br>';
$array[1] = "bar";
$array[3] = "foo";
echo $array[1];

/*
    foreach ($arra as $key => $value) {
                echo
                " <tr>
                <td>echo $value[id]</td>
                <td>echo $value[icon]</td>
                <td>echo $value[name]</td>
                <td>echo $value[age]</td>
                <td>echo $value[type]</td>
                </tr>"
       */
// phpinfo();

echo '<br>';
var_dump(time());
$now = time() + 6 * 60 * 60;
$for_now = date('Y-m-d H:i:s',$now);
echo '<br>';
var_dump($for_now);
echo '<br>';

$cur_time = "2020-11-10 08:32:52";
$cur = strtotime($cur_time);
var_dump($cur);

echo '<br>';
$users = [
    ['name' => '忘忧大师','age' => 60],
    ['name' => '无心','age' => 6]
];
$json_users = json_encode($users,JSON_UNESCAPED_UNICODE);
// $name1 = '忘忧大师';
var_dump($json_users);

echo '<br>';
$res = [
    'code' => 0,
    'mag' => 'success',
    'data' => [
        'src'=>'aaa'
    ]
    ];
var_dump(json_encode($res,256));


 
