<?php 
$users = [
        ['name' => '忘忧大师','age' => 60],
        ['name' => '无心','age' => 6]
    ];
    
    $name1 = '忘忧大师';
    // var_dump($users);