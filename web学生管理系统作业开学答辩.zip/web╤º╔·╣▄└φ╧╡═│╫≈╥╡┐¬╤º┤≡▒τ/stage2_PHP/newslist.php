
<?php
require_once '../server/connect.php';
//登录拦截
session_start();
// print_r($_SESSION);
if(!$_SESSION['is_login']) {
  //调回到登录页面
  echo "<script>alert('请先登录!');location.href='./login.html';</script>";
}
//1 查询
//查询总条数
$stmt = $pdo->query("SELECT COUNT(*) as num FROM `news`");//返回一个PDOStatement对象
$res = $stmt->fetch();
// var_dump($res);
$count = $res['num'];

$cur_page = empty($_GET['cur_page']) ? 1 : $_GET['cur_page'];
$page_size = 3;
$index = ($cur_page - 1)*3;
//1)使用query
$stmt = $pdo->query("SELECT * FROM `news` LIMIT $index,3"); //返回一个PDOStatement对象

$arra = $stmt->fetchAll(); //获取所有
// print_r($rows);

// foreach ($arra as $key => &$user) {
//   $user['show_time'] = date('Y-m-d',$user['create_time']);
//     $type_name = '';
//     switch ($user['type']) {
//         case '1':
//             $type_name = '老师';
//             break;
//         case '2':
//             $type_name = '学生';
//             break;
//         case '3':
//             $type_name = '工人';
//             break;
//         default:
//             $type_name= '未知';
//             break;
//     }
//     $user['type_name'] = $type_name;
// }
?>




<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>userlist</title>
  <link rel="stylesheet" href="../layui/css/layui.css">
</head>
<body>
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo layui-hide-xs layui-bg-black">学生管理系统</div>
    <!-- 头部区域（可配合layui 已有的水平导航） -->
    <ul class="layui-nav layui-layout-left">
      <!-- 移动端显示 -->
      <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-header-event="menuLeft">
        <i class="layui-icon layui-icon-spread-left"></i>
      </li>
      
      <li class="layui-nav-item layui-hide-xs"><a href="">控制台</a></li>
      <li class="layui-nav-item layui-hide-xs"><a href="">商品管理</a></li>
      <li class="layui-nav-item layui-hide-xs"><a href="">学生</a></li>
     
      <li class="layui-nav-item">
        <a href="javascript:;">其他系统</a>
        <dl class="layui-nav-child">
          <dd><a href="">menu 11</a></dd>
          <dd><a href="">menu 22</a></dd>
          <dd><a href="">menu 33</a></dd>
        </dl>
      </li>
    </ul>
    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item layui-hide layui-show-md-inline-block">
        <a href="javascript:;">
          <img src="//tva1.sinaimg.cn/crop.0.0.118.118.180/5db11ff4gw1e77d3nqrv8j203b03cweg.jpg" class="layui-nav-img">
         贤心
        </a>
        <dl class="layui-nav-child">
          <dd><a href="">Your Profile</a></dd>
          <dd><a href="">Settings</a></dd>
          <dd><a href="../server/server_logout.php">退出</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item" lay-header-event="menuRight" lay-unselect>
        <a href="javascript:;">
          <i class="layui-icon layui-icon-more-vertical"></i>
        </a>
      </li>
    </ul>
  </div>
  
  <div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav layui-nav-tree" lay-filter="test">
        <li class="layui-nav-item layui-nav-itemed">
          <a class="" href="javascript:;">学生管理</a>
          <dl class="layui-nav-child">
            <dd><a href="./userlist.php">学生列表</a></dd>
            <dd><a href="javascript:;">添加学生</a></dd>
            <dd><a href="javascript:;">修改学生</a></dd>
          
          </dl>
        </li>
        <li class="layui-nav-item">
          <a href="javascript:;">新闻管理</a>
          <dl class="layui-nav-child">
            <dd><a href="javascript:;">新闻列表</a></dd>
            <dd><a href="javascript:;">添加新闻</a></dd>
            
          </dl>
        </li>
        
      </ul>
    </div>
  </div>
  
  <div class="layui-body">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
      <a href="./useradd.php" class="layui-btn">
            <i class="layui-icon layui-icon-add-circle"></i>
            添加新闻
      </a>
      <input type="text" name="search" placeholder="请输入搜索关键词">
      <button class="layui-btn layui-btn-sm" onclick="search()" >搜索</button>

         <table class="layui-table">
            <colgroup>
                <col width="150">
                <col width="200">
                <col>
              </colgroup>
            <thead>
                <tr>
                    <td>编号</td>
                    <td>标题</td>
                    <td>主图</td>
                    <td>分类</td>
                    <td>发布时间</td>
                </tr>
            </thead>
            <tbody >
            <?php
            foreach ($arra as $key => &$news) {
                echo
                " <tr>
                <td>$news[id]</td>
                <td> $news[title]</td>
                <td><img src='../server/uploads/$news[img]' alt=''></td>
                <td> $news[name]</td>
                <td>$news[create_name]</td>
                <td>
                    <a class='layui-btn layui-btn-sm' href='./newsedit.php?id=news[id]' >编辑</a>
                    <button onclick='del($news[id])' class='layui-btn layui-btn-sm layui-btn-danger'>删除</button>
                </td>
                </tr>";
            };
            ?> 
            </tbody>
         </table>
         <div id="pages"></div>
    </div>
  </div>
  
  <div class="layui-footer">
    <!-- 底部固定区域 -->
    @layui.com - 底部固定区域
  </div>
</div>
<script src="../layui/jquery.min.js"></script>
<script src="../layui/layui.js"></script>
<script>
    
  function loadData(users) {
  var contents = '';
  var tbody = document.getElementById("content");
  
for (let index = 0;index < users.length;index++) {
    const user = users[index];
           contents += ` <tr>
                        <td>${news.id}</td>
                        <td><img src="${news.img}" alt=""></td>
                        <td>${news.username}</td>
                        <td>${news.age}</td>
                        <td>${news.type}</td>
                        <td>
                            <a class="layui-btn layui-btn-sm" href="./useredit.html?id=${news.id}" >编辑</a>
                            <button onclick='del(${news.id})' class="layui-btn layui-btn-sm layui-btn-danger">删除</button>
                        </td>
                    </tr>` 
 }
 console.log(contents);
 tbody.innerHTML = contents;
//  console.log(tbody);
}

function search(){
  //1、获取数据
  var search = document.querySelector('input[name=search]').value;
  console.log(search);
  //2、过滤
  var strusers = localStorage.getItem("users");
  var users = JSON.parse(strusers);
  users = users.filter(user => user.username.indexOf(search) >= 0);
  //3、显示数据
  loadData(users);
 } 

    function del(id) {
      layer.confirm('确认删除' + id + '?', {
        btn: ['确认', '取消',] //可以无限个按钮
        }, function(index, layero){
          //调用服务端的删除接口
          location.href = `../server/server_userdel.php?id= ${id}`
           layer.close(index);
        }, function(index){
        //按钮【按钮二】的回调
        });
    }

    
    
              
  
  
  //JS 
  layui.use(['element', 'layer', 'util'], function(){
    var element = layui.element
    ,layer = layui.layer
    ,util = layui.util
    ,$ = layui.$
    ,laypage = layui.laypage;
  
    //执行一个laypage实例
    laypage.render({
      elem: 'pages' //注意，这里的 test1 是 ID，不用加 # 号
      ,count: <?php echo $count ?> //数据总数，从服务端得到
      ,limit: 3
      ,curr: <?php echo $cur_page ?>
      ,jump: function(obj, first){
        //obj包含了当前分页的所有参数，比如：
        
        console.log(obj.curr); //得到当前页，以便向服务端请求对应页的数据。
        console.log(obj.limit); //得到每页显示的条数
        
        //首次不执行
        if(!first){
          //do something
          location.href = './newslist.php?cur_page=' + obj.curr;
        }
      }
    });
    
    //头部事件
    util.event('lay-header-event', {
      //左侧菜单事件
      menuLeft: function(othis){
        layer.msg('展开左侧菜单的操作', {icon: 0});
      }
      ,menuRight: function(){
        layer.open({
          type: 1
          ,content: '<div style="padding: 15px;">处理右侧面板的操作</div>'
          ,area: ['260px', '100%']
          ,offset: 'rt' //右上角
          ,anim: 5
          ,shadeClose: true
        });
      }
    });
    
  });

      
</script> 

</body> 
</html>