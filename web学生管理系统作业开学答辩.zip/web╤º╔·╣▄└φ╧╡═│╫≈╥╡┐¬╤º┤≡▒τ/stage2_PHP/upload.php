<?php
var_dump($_POST);
var_dump($_FILES);

move_uploaded_file($_FILES['pic']['tmp_name'],'./uploads/'.$_FILES['pic']['name']);